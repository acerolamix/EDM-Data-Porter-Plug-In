﻿

namespace FonctionsTMA
{
    using CADIS.Plugin;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text.RegularExpressions;
    using ToolBoxTMA;

    /// <summary>
    /// Plugin de renommage des fichiers horodatés
    /// </summary>
    public class Renommer : DataPorterPlugin
    {
        #region Constants

        /// <summary>
        /// Option de recherche dans les sous dossiers
        /// </summary>
        private const String PRM_INCLURE_SS_REP = "Flag indiquant si la fonction doit aussi traiter les sous-dossiers";
        #endregion

        #region Properties

        /// <summary>
        /// Dictionnaire des paramètres d'entrée - Propriété en lecture seule
        /// </summary>
        public override Dictionary<string, string> InputParameters
        {
            get
            {
                // Initialisation des paramètres d'entré Markit
                Dictionary<String, String> inputs = new Dictionary<string, string>();

                inputs.Add(Concatener.PRM_REP_IN, "Mandatory - Répertoire d'entré");

                inputs.Add(Concatener.PRM_EXTENSION, "Optional - Type des fichiers traités");                             
                inputs.Add(PRM_INCLURE_SS_REP, "Optional - Caractère indiquant si les sous-dossiers doivent être scrutés : 'Y' -> Inclure les sous-dossiers");
                inputs.Add(Concatener.PRM_VERBOSE, "Optional - Caractère permettant d'activer les logs : 'Y' -> Active l'affichage");

                return inputs;
            }
        }

        /// <summary>
        /// Dictionnaire des paramètres de sortie - Propriété en lecture seule
        /// </summary>
        public override Dictionary<string, string> OutputParameters
        {
            get
            {
                return GetOutputParameters();
            }
        }

        /// <summary>
        /// Description du plugin Markit - Propriété en lecture seule
        /// </summary>
        public override string Description
        {
            get { return "Renommage des fichiers horodatés."; }
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// Paramètres de sortie du plugin Markit
        /// </summary>
        /// <returns>Renvoi le dictionnaire des paramètre de sortie</returns>
        public Dictionary<string, string> GetOutputParameters()
        {

            Dictionary<string, string> outputs = new Dictionary<string, string>();
            // Initialisation des paramètres de sortie Markit
            outputs.Add(Concatener.OUTPUT_RETURNCODE, "ReturnCode (0 = success)");
            outputs.Add(Concatener.OUTPUT_ERRORMESSAGE, "Error Message");

            return outputs;
        }

        /// <summary>
        /// Point d'entrée de la dll/méthode sélectionnée depuis l'interface Markit
        /// </summary>
        /// <param name="inputParameters">Dictionnaire des paramètres d'entré</param>
        /// <param name="cadisVariables">Dictionnaire des variables Cadis</param>
        /// <returns></returns>
        protected override Dictionary<string, string> Run(Dictionary<string, string> inputParameters, Dictionary<string, string> cadisVariables)
        {
            Dictionary<string, string> outputParams = new Dictionary<string, string>();

            #region Validate Input params

            // Contrôle des paramètres (obligatoires et optionnels) saisis depuis l'interface Markit
            string monRepIn = GetMandatoryParameter(inputParameters, Concatener.PRM_REP_IN);
            string extension = String.IsNullOrEmpty(inputParameters[Concatener.PRM_EXTENSION].Trim()) ? ".csv" : inputParameters[Concatener.PRM_EXTENSION].Trim();
            extension = extension.StartsWith(".") ? extension : "." + extension;           
            SearchOption optionRecherche = inputParameters[PRM_INCLURE_SS_REP].Trim() == "Y" ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            bool doVerbs = inputParameters[Concatener.PRM_VERBOSE].Trim() == "Y" ? true : false;
            #endregion

            #region Invocation de la fonction  
            
            try
            {
                // Initialisation de la classe de gestion des fichiers
                if (doVerbs)
                    LogMessage(MessageSeverity.Information, "Initialisation de la fonction de renommage");
                FileHandler gestFic = new FileHandler(monRepIn, optionRecherche, extension);

                // Récupération des fichiers dê même type
                if (doVerbs)
                    LogMessage(MessageSeverity.Information, "Récupération des fichiers *" + extension);
                List<string> files2Process = gestFic.RetrieveComonFiles();
                

                if (files2Process != null && files2Process.Where(fi => Regex.IsMatch(fi, Concatener.timePattern + extension +"$" )).Count() > 0)
                {
                    files2Process = files2Process.Where(fi => Regex.IsMatch(fi, Concatener.timePattern + extension +"$" )).ToList();

                    // Affichage des fichiers à renommer
                    if (doVerbs)
                    {
                        LogMessage(MessageSeverity.Information, "Liste des fichiers à renommer : ");
                        foreach (string nom in files2Process)
                        {
                            LogMessage(MessageSeverity.Information, nom);    
                        }
                    }

                    // Renommage des fichiers
                    if (doVerbs)
                        LogMessage(MessageSeverity.Information, "Renommage des fichiers trouvés");
                    files2Process = gestFic.RenameTimeSpanFiles(files2Process);

                    // Affichage de la liste des fichiers renommés
                    if (doVerbs)
                    {
                        LogMessage(MessageSeverity.Information, "Liste des fichiers renommés : ");
                        foreach (string nom in files2Process)
                        {
                            LogMessage(MessageSeverity.Information, nom);
                        }
                    }
                }
                // Si aucun horodaté est trouvé alors on lance une exeption
                else
                    throw new Exception("Aucun fichier horodaté a été trouvé");

                if (doVerbs)
                    LogMessage(MessageSeverity.Information, "Renommage des fichiers terminé");

                // Gestion du code retour - En cas de succès
                outputParams.Add(Concatener.OUTPUT_RETURNCODE, "0");
                outputParams.Add(Concatener.OUTPUT_ERRORMESSAGE, String.Empty);
            }
            catch (Exception ex)
            {
                // Gestion du code retour - En cas d'erreur
                outputParams.Add(Concatener.OUTPUT_RETURNCODE, "1");
                outputParams.Add(Concatener.OUTPUT_ERRORMESSAGE, ex.Message);
                // Lancement d'une exception en cas d'erreur
                throw new Exception(outputParams[Concatener.OUTPUT_ERRORMESSAGE]);
            }
            return outputParams;
            #endregion          
        }
        #endregion

    }
}
